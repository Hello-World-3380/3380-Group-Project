public class ExportLog {

    public ExportLog() {
    }
//
    public void log(String input) {
        System.out.println(input);
    }
}
