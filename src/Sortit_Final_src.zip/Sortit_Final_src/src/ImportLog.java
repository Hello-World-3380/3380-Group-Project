public class ImportLog {

    public ImportLog(){

    }

    public void log(String input){
        System.out.println(input);
    }
}
