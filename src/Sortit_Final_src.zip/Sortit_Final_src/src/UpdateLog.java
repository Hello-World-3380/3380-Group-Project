public class UpdateLog {

    //initializes
    public UpdateLog(){
    }

    //logs updates
    public void log(String input){
        System.out.println(input);
    }
}
